import numpy as np

def Num():
    while(True):
        try:
            x=input()
            x=int(x)
            break
        except:
            print("Error, esto no es un numero, intentalo nuevamente.")
    return(x)

def menu():
    print("1.- Crear ficha mascota.")
    print("2.- Buscar por codigo de mascota.")
    print("3.- Eliminar por codigo de mascota.") 
    print("4.- Listar mascotas.") 
    print("5.- Salir.") 

def codigo():
    while(True):
        x=input()
        if x=="":
            print("Error, campo ingresado vacío, reintente")
        else:
            break
    return(x)

def mascota(i,j):
    if j==0:
        print("Nombre mascota: ", masc[i,j])
    elif j==1:
        print("Codigo mascota: ", masc[i,j])  
    elif j==2:
        print("Edad mascota: ", masc[i,j])
    elif j==3:
        print("Peso: ", masc[i,j])
    elif j==4:
        print("Raza: ", masc[i,j])
    elif j==5:
        print("Especie:", masc[i,j])                     
    elif j==6:
        print("Diagnostico:", masc[i,j])    
    elif j==7:
        print("medicamentos recetados:")
        print(masc[i.j])

masc=np.empty([50,7],dtype="object") 
f=0
while(True):
    menu()
    opt=Num()
    if opt==1:
        for i in range(0,7):
            if i==0:
                print("Ingrese el nombre de la mascota.")
                masc[f,i]=input()
            elif i==1:
                print("Ingrese el codido de la mascota.")
                masc[f,i]=codigo()
            elif i==2:
                print("Ingrese la edad de la mascota.")
                masc[f,i]=input()
            elif i==3:
                print("Ingrese el peso de la mascota.")
                masc[f,i]=input()
            elif i==4:
                print("Ingrese la raza de la mascota.")
                masc[f,i]=input()
            elif i==5:
                print("Ingrese la especie de la mascota.")
                masc[f,i]=input()
            elif i==6:
                print("Diagnostico de la mascota")
                masc[f,i]=input()
            elif i==7:
                print("Ingrese medicamentos recetados para la mascota.")
                masc[f,i]=input()        
        f+=1
        print("Mascota ingresada con exito :3 .")
    elif opt==2:
        print("Ingrese el codigo de la mascota que desea buscar: ")
        x=input()
        for i in range(0,50):
            if x==masc[i,1]:
                print("Paciente encontrado, sus datos son los siguientes:")
                for j in range(0,7):
                    mascota(i,j)
                 
                break
        else:
            print("mascota no encontrada no encontrado")

    elif opt==3:
        print("Ingrese el codigo del pacuente que desea elminar.")
        x=input()
        for i in range(0,50):
            if x==masc[i,1]:
                masc=np.delete(masc,i, axis=0)
                print("Mascota eliminada con éxito")
                break
        else:
            print("Mascota no encontrada :< .")
    elif opt==4:
        for i in range(0,f):
            print("mascota:")
            for j in range(0,6):
                mascota(i,j)        

    elif opt==5:
        break
    else:
        print("Error, ingrese opción válida")

with open('datos.txt', 'r') as archivo:
    contenido = archivo.read()
    print(contenido)

